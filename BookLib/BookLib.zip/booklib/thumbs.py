"""Cover thumbnails via macOS built-in tools — no third-party libraries.

Primary:  sips (converts page 1 of a PDF to PNG)
Fallback: qlmanage -t (Quick Look thumbnail)
Both absent / both fail -> returns None and the server serves a placeholder.
Thumbnails are generated lazily on first request and cached in
<library>/.booklib/thumbs/<hash>.png.
"""

import os
import shutil
import subprocess
import tempfile

THUMB_HEIGHT = 480


def ensure_thumb(book_hash, pdf_path, thumbs_dir):
    out = os.path.join(thumbs_dir, book_hash + ".png")
    if os.path.exists(out):
        return out
    if not os.path.exists(pdf_path):
        return None
    os.makedirs(thumbs_dir, exist_ok=True)
    if _try_sips(pdf_path, out) or _try_qlmanage(pdf_path, out):
        return out
    return None


def _try_sips(pdf_path, out):
    if shutil.which("sips") is None:
        return False
    try:
        r = subprocess.run(
            ["sips", "-s", "format", "png", "-Z", str(THUMB_HEIGHT),
             pdf_path, "--out", out],
            capture_output=True, timeout=30,
        )
    except (subprocess.SubprocessError, OSError):
        return False
    return r.returncode == 0 and os.path.exists(out) and os.path.getsize(out) > 0


def _try_qlmanage(pdf_path, out):
    if shutil.which("qlmanage") is None:
        return False
    with tempfile.TemporaryDirectory() as tmp:
        try:
            r = subprocess.run(
                ["qlmanage", "-t", "-s", str(THUMB_HEIGHT), "-o", tmp, pdf_path],
                capture_output=True, timeout=30,
            )
        except (subprocess.SubprocessError, OSError):
            return False
        produced = os.path.join(tmp, os.path.basename(pdf_path) + ".png")
        if r.returncode == 0 and os.path.exists(produced):
            shutil.move(produced, out)
            return True
    return False
