#!/bin/sh
# 書庫.app を生成する: launcher.applescript のコンパイル + アイコン適用。
# osacompile 単体だとアイコンが既定のアプレットに戻るため、必ずこちらを使う。
# 使うツールはすべて macOS 同梱(osacompile / qlmanage / sips / iconutil / codesign)。
#
# 使い方: sh tools/make_app.sh
set -e
cd "$(dirname "$0")/.."

osacompile -o 書庫.app tools/launcher.applescript

# 資料/booklib-icon-light.svg → 824px描画 → 透過1024pxに角丸合成 → .icns
# (qlmanageは白背景で描画するため、make_icon.py で透過角丸に加工する)
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
qlmanage -t -s 824 -o "$TMP" 資料/booklib-icon-light.svg > /dev/null 2>&1
python3 tools/make_icon.py "$TMP/booklib-icon-light.svg.png" "$TMP/icon_1024.png"
SRC="$TMP/icon_1024.png"
ISET="$TMP/icon.iconset"
mkdir "$ISET"
for px in 16 32 128 256 512; do
    sips -z "$px" "$px" "$SRC" --out "$ISET/icon_${px}x${px}.png" > /dev/null
    sips -z "$((px*2))" "$((px*2))" "$SRC" --out "$ISET/icon_${px}x${px}@2x.png" > /dev/null
done
iconutil -c icns "$ISET" -o 書庫.app/Contents/Resources/applet.icns

# アイコン差し替えで署名が壊れるためアドホック再署名
codesign --force --sign - 書庫.app 2>/dev/null

echo "書庫.app を生成しました(アイコン適用済み)"
