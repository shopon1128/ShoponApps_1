"""アプリアイコン用PNG加工ツール(標準ライブラリのみ)。

qlmanage は SVG を白背景に潰して描画するため、透過角丸アイコンが作れない。
このスクリプトは白背景で描画済みのPNGを受け取り、
  1. 1024x1024 の透過キャンバス中央に配置(macOS標準の824px枠に合わせる)
  2. 元SVGと同じ比率の角丸(rx = 幅 x 116/512)で四隅を透過マスク
して RGBA PNG として書き出す。

使い方: python3 make_icon.py <入力824px.png> <出力1024px.png>
"""

import struct
import sys
import zlib
from typing import List

CANVAS: int = 1024          # macOSアイコンのキャンバス
CONTENT: int = 824          # 標準グリッドでアートワークが占める辺
RX_RATIO: float = 116 / 512  # 元SVGの角丸比率
AA_WIDTH: float = 1.5        # 角のアンチエイリアス幅(px)


def read_png(path: str) -> List[bytearray]:
    """8bitのRGB/RGBA PNGを読み、行ごとのRGBAバイト列に展開して返す。"""
    data = open(path, "rb").read()
    assert data[:8] == b"\x89PNG\r\n\x1a\n", "PNGではない"
    pos, idat = 8, b""
    width = height = channels = 0
    while pos < len(data):
        ln, typ = struct.unpack(">I4s", data[pos:pos + 8])
        body = data[pos + 8:pos + 8 + ln]
        if typ == b"IHDR":
            width, height, depth, ctype = struct.unpack(">IIBB", body[:10])
            assert depth == 8 and ctype in (2, 6), f"未対応形式 depth={depth} ctype={ctype}"
            channels = 3 if ctype == 2 else 4
        elif typ == b"IDAT":
            idat += body
        pos += 12 + ln
    raw = zlib.decompress(idat)
    stride = width * channels
    rows: List[bytearray] = []
    prev = bytearray(stride)
    off = 0
    for _ in range(height):
        filt = raw[off]
        line = bytearray(raw[off + 1:off + 1 + stride])
        off += 1 + stride
        # PNGフィルタの復元(仕様の5種)
        for i in range(stride):
            left = line[i - channels] if i >= channels else 0
            up = prev[i]
            ul = prev[i - channels] if i >= channels else 0
            if filt == 1:
                line[i] = (line[i] + left) & 0xFF
            elif filt == 2:
                line[i] = (line[i] + up) & 0xFF
            elif filt == 3:
                line[i] = (line[i] + (left + up) // 2) & 0xFF
            elif filt == 4:
                p = left + up - ul
                pa, pb, pc = abs(p - left), abs(p - up), abs(p - ul)
                pred = left if pa <= pb and pa <= pc else (up if pb <= pc else ul)
                line[i] = (line[i] + pred) & 0xFF
        prev = line
        if channels == 3:  # RGB→RGBA(不透過)
            rgba = bytearray(width * 4)
            for x in range(width):
                rgba[x * 4:x * 4 + 3] = line[x * 3:x * 3 + 3]
                rgba[x * 4 + 3] = 255
            rows.append(rgba)
        else:
            rows.append(line)
    return rows


def write_png(path: str, rows: List[bytearray], width: int, height: int) -> None:
    """RGBA行列を8bit RGBA PNG(フィルタなし)として書き出す。"""
    def chunk(typ: bytes, body: bytes) -> bytes:
        return (struct.pack(">I", len(body)) + typ + body
                + struct.pack(">I", zlib.crc32(typ + body)))
    raw = b"".join(b"\x00" + bytes(r) for r in rows)
    with open(path, "wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n")
        f.write(chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)))
        f.write(chunk(b"IDAT", zlib.compress(raw, 9)))
        f.write(chunk(b"IEND", b""))


def corner_alpha(x: float, y: float, size: int, rx: float) -> float:
    """角丸矩形(0,0)-(size,size)に対するピクセル中心(x,y)の被覆率(0-1)。"""
    # 最寄りの角の円中心からの距離で判定。辺の中央部は常に内側
    cx = rx if x < rx else (size - rx if x > size - rx else x)
    cy = rx if y < rx else (size - rx if y > size - rx else y)
    d = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5
    return max(0.0, min(1.0, (rx - d) / AA_WIDTH + 0.5))


def main() -> None:
    src, dst = sys.argv[1], sys.argv[2]
    art = read_png(src)
    size = len(art[0]) // 4
    assert len(art) == size == CONTENT, f"入力は{CONTENT}px正方形を想定(実際{size})"
    rx = size * RX_RATIO
    margin = (CANVAS - CONTENT) // 2
    blank = bytearray(CANVAS * 4)
    canvas: List[bytearray] = [bytearray(blank) for _ in range(CANVAS)]
    for y in range(size):
        row_out = canvas[y + margin]
        row_in = art[y]
        for x in range(size):
            # 角の周辺だけ被覆率を計算(それ以外は完全内側)
            near_corner = ((x < rx or x > size - rx)
                           and (y < rx or y > size - rx))
            a = corner_alpha(x + 0.5, y + 0.5, size, rx) if near_corner else 1.0
            if a <= 0.0:
                continue
            o = (x + margin) * 4
            row_out[o:o + 3] = row_in[x * 4:x * 4 + 3]
            row_out[o + 3] = round(255 * a)
    write_png(dst, canvas, CANVAS, CANVAS)


if __name__ == "__main__":
    main()
