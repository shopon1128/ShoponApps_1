-- 書庫.app: Finderからダブルクリックでbooklibを起動し、Safariで開く。
-- サーバは --auto-quit 付きで起動するため、タブを閉じれば自動終了する。
-- 既に起動済みならブラウザを開くだけ(二重起動しない)。
--
-- 動作ログ: /tmp/booklib_launcher.log(各段階の時刻)
--           /tmp/booklib_server.log(サーバの標準出力)
--
-- .appの生成(パスを変えた場合も同じコマンドで作り直す):
--   cd /path/to/booklib
--   osacompile -o 書庫.app tools/launcher.applescript

set appDir to "/path/to/booklib"
set thePort to "8323"
set logCmd to " >> /tmp/booklib_launcher.log"

do shell script "echo \"$(date '+%F %T') --- 起動 ---\"" & logCmd

-- 未起動なら起動(homebrew版python3を優先)。
-- 注意: ここで `cd ... && python &` と書いてはいけない。&& の複合コマンドを
-- & で背景化するとサブシェルが do shell script の出力パイプを握ったまま
-- pythonの終了を待ち続け、サーバが死ぬまでスクリプトがブロックする
-- (LESSONS.md 2026-07-06)。app.py は __file__ 基準で動くので cd 不要。
do shell script "if /usr/sbin/lsof -nP -i :" & thePort & " >/dev/null 2>&1; then echo \"$(date '+%T') 既に起動済み\"" & logCmd & "; else PATH=/opt/homebrew/bin:/usr/local/bin:$PATH nohup python3 " & quoted form of (appDir & "/app.py") & " --auto-quit </dev/null >> /tmp/booklib_server.log 2>&1 & echo \"$(date '+%T') サーバ起動コマンド発行\"" & logCmd & "; fi"

-- ページが実際に返るまで最大5秒待つ(lsofでなくcurlで「応答」を確認)
do shell script "for i in $(seq 1 25); do curl -s -o /dev/null --max-time 1 http://127.0.0.1:" & thePort & "/ && break; sleep 0.2; done; echo \"$(date '+%T') 応答待ち完了\"" & logCmd

do shell script "open -a Safari 'http://localhost:" & thePort & "/'; echo \"$(date '+%T') Safariを開いた rc=$?\"" & logCmd
