"""SQLite layer: schema and queries.

Design decisions (see README):
- books.hash (SHA-256 of file content) is the primary key. Metadata survives
  renames and moves because identity is content, not path.
- Author stays a plain text column until multi-author management actually hurts.
- Deletion never removes rows; books are flagged missing=1 instead.
"""

import sqlite3
import unicodedata

SCHEMA = """
CREATE TABLE IF NOT EXISTS books (
    hash     TEXT PRIMARY KEY,
    path     TEXT NOT NULL,
    title    TEXT NOT NULL DEFAULT '',
    author   TEXT NOT NULL DEFAULT '',
    size     INTEGER NOT NULL,
    mtime    REAL NOT NULL,
    added_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
    missing  INTEGER NOT NULL DEFAULT 0,
    superseded_by TEXT  -- 差し替えで引き継ぎ済みなら後継本のhash
);
CREATE TABLE IF NOT EXISTS tags (
    id   INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS book_tags (
    book_hash TEXT NOT NULL REFERENCES books(hash) ON DELETE CASCADE,
    tag_id    INTEGER NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
    PRIMARY KEY (book_hash, tag_id)
);
CREATE INDEX IF NOT EXISTS idx_books_path ON books(path);
"""


def _nfc(value):
    # macOS filenames are stored decomposed (NFD: "ダ" = "タ" + U+3099), and
    # titles default to the filename stem, while browser input is composed
    # (NFC). Normalizing both sides at query time lets them match without
    # rewriting stored data.
    return unicodedata.normalize("NFC", value) if isinstance(value, str) else value


def connect(db_path):
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.create_function("nfc", 1, _nfc, deterministic=True)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.executescript(SCHEMA)
    _migrate(conn)
    return conn


def _migrate(conn):
    # CREATE TABLE IF NOT EXISTS is a no-op for existing databases, so
    # columns added after the first release must be patched in here.
    cols = {r["name"] for r in conn.execute("PRAGMA table_info(books)")}
    if "superseded_by" not in cols:
        conn.execute("ALTER TABLE books ADD COLUMN superseded_by TEXT")
        conn.commit()


def _escape_like(term):
    return term.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def search_books(conn, query="", tags=None, sort="added"):
    """Return books with their tags. query matches title/author/path.
    tags: list of tag names; a book must carry ALL of them (AND)."""
    tags = [t for t in (tags or []) if t]
    sql = ["SELECT b.* FROM books b"]
    params = []
    where = []
    if tags:
        marks = ",".join("?" * len(tags))
        sql.append(
            "JOIN book_tags bt ON bt.book_hash = b.hash "
            "JOIN tags t ON t.id = bt.tag_id"
        )
        where.append(f"t.name IN ({marks})")
        params += tags
    if query:
        # NOTE: path is deliberately NOT searched — the library root's own
        # path would match every book (e.g. a folder named "Books" makes the
        # query "book" hit everything). Titles default to the filename stem,
        # so filename search is covered for unedited books.
        like = f"%{_escape_like(_nfc(query))}%"
        where.append(
            "(nfc(b.title) LIKE ? ESCAPE '\\' OR nfc(b.author) LIKE ? ESCAPE '\\')"
        )
        params += [like, like]
    if where:
        sql.append("WHERE " + " AND ".join(where))
    if tags:
        sql.append("GROUP BY b.hash HAVING COUNT(DISTINCT t.name) = ?")
        params.append(len(tags))
    order = {
        "added": "b.added_at DESC, b.title",
        "added_asc": "b.added_at ASC, b.title",
        "title": "b.title COLLATE NOCASE, b.added_at DESC",
        "title_desc": "b.title COLLATE NOCASE DESC, b.added_at DESC",
        "author": "b.author COLLATE NOCASE, b.title COLLATE NOCASE",
        "author_desc": "b.author COLLATE NOCASE DESC, b.title COLLATE NOCASE",
    }.get(sort, "b.added_at DESC, b.title")
    sql.append("ORDER BY " + order)
    rows = conn.execute(" ".join(sql), params).fetchall()
    books = [dict(r) for r in rows]
    tag_map = _tags_for(conn, [b["hash"] for b in books])
    for b in books:
        b["tags"] = tag_map.get(b["hash"], [])
    return books


def _tags_for(conn, hashes):
    if not hashes:
        return {}
    marks = ",".join("?" * len(hashes))
    rows = conn.execute(
        f"SELECT bt.book_hash, t.name FROM book_tags bt "
        f"JOIN tags t ON t.id = bt.tag_id "
        f"WHERE bt.book_hash IN ({marks}) ORDER BY t.name",
        hashes,
    ).fetchall()
    out = {}
    for r in rows:
        out.setdefault(r["book_hash"], []).append(r["name"])
    return out


def get_book(conn, book_hash):
    row = conn.execute("SELECT * FROM books WHERE hash = ?", (book_hash,)).fetchone()
    if row is None:
        return None
    book = dict(row)
    book["tags"] = _tags_for(conn, [book_hash]).get(book_hash, [])
    return book


def update_book(conn, book_hash, title=None, author=None, tags=None,
                inherit_from=None):
    # inherit_from: 差し替え元(所在不明の旧版)のhash。指定されたら旧版に
    # 「この本へ引き継ぎ済み」の印を付け、以後の引き継ぎ候補から外す
    if inherit_from is not None:
        conn.execute(
            "UPDATE books SET superseded_by = ? WHERE hash = ?",
            (book_hash, inherit_from),
        )
    if title is not None:
        conn.execute("UPDATE books SET title = ? WHERE hash = ?", (title.strip(), book_hash))
    if author is not None:
        conn.execute("UPDATE books SET author = ? WHERE hash = ?", (author.strip(), book_hash))
    if tags is not None:
        conn.execute("DELETE FROM book_tags WHERE book_hash = ?", (book_hash,))
        for name in tags:
            name = name.strip()
            if not name:
                continue
            conn.execute("INSERT OR IGNORE INTO tags(name) VALUES (?)", (name,))
            conn.execute(
                "INSERT OR IGNORE INTO book_tags(book_hash, tag_id) "
                "SELECT ?, id FROM tags WHERE name = ?",
                (book_hash, name),
            )
    conn.execute(
        "DELETE FROM tags WHERE id NOT IN (SELECT DISTINCT tag_id FROM book_tags)"
    )
    conn.commit()


def delete_book(conn, book_hash):
    # Permanent removal, allowed only for missing books (caller enforces).
    # book_tags rows go via FK cascade; orphaned tag names are swept like
    # update_book does.
    conn.execute("DELETE FROM books WHERE hash = ?", (book_hash,))
    conn.execute(
        "DELETE FROM tags WHERE id NOT IN (SELECT DISTINCT tag_id FROM book_tags)"
    )
    conn.commit()


def list_tags(conn):
    rows = conn.execute(
        "SELECT t.name, COUNT(bt.book_hash) AS count FROM tags t "
        "LEFT JOIN book_tags bt ON bt.tag_id = t.id "
        "GROUP BY t.id ORDER BY t.name"
    ).fetchall()
    return [dict(r) for r in rows]
